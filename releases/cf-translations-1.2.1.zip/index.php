<?php
if( ! defined( 'ABSPATH' ) ){
	exit;
}
?>
<!---cf-translate-app--><div id="cf-translate-app"></div><!---/cf-translate-app-->