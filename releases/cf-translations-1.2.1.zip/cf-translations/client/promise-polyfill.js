import Promise from 'promise-polyfill'

window.Promise = window.Promise || Promise
