# Caldera Forms Translations - Multiligual WordPress Forms
Translate Caldera Forms fields: coming to WordPress.org soon.

What it does:
* Translate form field labels, descriptions, default values and option values for select fields.
* Adds a language picker field.

One form, all the languages you need.

* [Documentation](https://calderawp.com/doc/caldera-forms-translation-getting-started/)
* Functional beta, please test. Coming to WordPress.org soon.
* Requires Caldera Forms 1.4.4 or later.

[Support for WPML coming soon](https://github.com/CalderaWP/cf-translate/issues/13).

<img src="https://calderawp.com/wp-content/uploads/2016/10/cf-translate-choose-form.png" />

<img src="https://calderawp.com/wp-content/uploads/2016/10/cf-translate-add-language.png" />

<img src="https://calderawp.com/wp-content/uploads/2016/10/cf-translations-full-view.png />

