<div class="caldera-config-group">
	<label for="{{_id}}_placeholder">
		<?php esc_html_e(' Default Language', 'caldera-forms'); ?>
	</label>
	<div class="caldera-config-field">
		<input type="text" id="{{_id}}_placeholder" class="block-input field-config" name="{{_name}}[placeholder]" value="{{placeholder}}">
	</div>
</div>
